package country;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadState {
	
	

	
	public List<String> stateList(String country){
	
		 String FILENAME = "C:\\Users\\Ranjit\\eclipse-workspace\\ProjectWork\\WebContent\\"+country+".txt";
		BufferedReader br = null;
		FileReader fr = null;
		List<String> str=new ArrayList<String>();
		try {

			//br = new BufferedReader(new FileReader(FILENAME));
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);

			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				str.add(sCurrentLine);
				System.out.println(sCurrentLine);
				
			}

			for(String str1:str) {
			
				System.out.println("new state"+str1);
			}
			
		//return str;	
			
		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
		return str;



}

}
